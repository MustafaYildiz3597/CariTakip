﻿namespace dbDataSetTableAdapters
{
    internal class TBLSTOKTableAdapter
    {
    }
}